# Save the current disk usage (POSIX output format) in the rescue image
df -Plh > $VAR_DIR/layout/config/df.txt
