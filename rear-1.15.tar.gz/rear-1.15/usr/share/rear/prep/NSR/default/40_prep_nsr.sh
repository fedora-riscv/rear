#
# prepare stuff for NSR
#

COPY_AS_IS=( "${COPY_AS_IS[@]}" "${COPY_AS_IS_NSR[@]}" )
COPY_AS_IS_EXCLUDE=( "${COPY_AS_IS_EXCLUDE[@]}" "${COPY_AS_IS_EXCLUDE_NSR[@]}" )
PROGS=( "${PROGS[@]}" "${PROGS_NSR[@]}" fmt )
