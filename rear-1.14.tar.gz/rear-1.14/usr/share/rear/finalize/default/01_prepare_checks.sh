# prepare some checks
# we want to tell the user if we didn't install a boot loader. To accomplish this we set a variable
# that is unset by all boot-loader installation scripts
NOBOOTLOADER=1
