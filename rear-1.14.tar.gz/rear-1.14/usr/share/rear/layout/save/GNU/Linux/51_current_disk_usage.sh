# Save the current disk usage in the rescue image
df -h > $VAR_DIR/layout/config/df.txt